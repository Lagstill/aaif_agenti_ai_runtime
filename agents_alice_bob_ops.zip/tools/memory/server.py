"""
Memory tool: a SQLite key/value store behind HTTP.
/data is a named volume: kill every container and the memories survive.
Memory is a runtime primitive, not a bigger context window.
"""

import os
import sqlite3
from contextlib import closing

from fastapi import FastAPI
from pydantic import BaseModel

DB_PATH = os.getenv("DB_PATH", "/data/memory.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

# A realistic first "yesterday" for each agent. INSERT OR IGNORE: only fills a fresh store.
SEED = {
    "alice:yesterday": "Got Acme's SSO integration working in staging; prod blocked on their firewall allowlist.",
    "bob:yesterday": "Scheduled four onsites for the FDE role; two offer letters waiting on comp approval.",
    "ops:yesterday": "db-2 disk alert fired twice overnight, auto-resolved. No runbook for it.",
}

with closing(sqlite3.connect(DB_PATH)) as c:
    c.execute("CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT)")
    c.executemany("INSERT OR IGNORE INTO kv (key, value) VALUES (?, ?)", SEED.items())
    c.commit()

app = FastAPI()


class RecallArgs(BaseModel):
    key: str


class RememberArgs(BaseModel):
    key: str
    value: str


@app.post("/recall")
def recall(args: RecallArgs):
    with closing(sqlite3.connect(DB_PATH)) as c:
        row = c.execute("SELECT value FROM kv WHERE key = ?", (args.key,)).fetchone()
    return {"key": args.key, "value": row[0] if row else None}


@app.post("/remember")
def remember(args: RememberArgs):
    with closing(sqlite3.connect(DB_PATH)) as c:
        c.execute("INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)", (args.key, args.value))
        c.commit()
    return {"ok": True, "key": args.key}


@app.get("/health")
def health():
    return {"ok": True}
