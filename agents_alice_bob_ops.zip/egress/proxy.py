"""
LLM egress: the agents' only door to the internet. A stdlib HTTPS CONNECT proxy that
tunnels to ALLOW_HOSTS and refuses everything else. TLS stays end-to-end; it sees hostnames only.
"""

import asyncio
import os

ALLOW = set(os.getenv("ALLOW_HOSTS", "api.anthropic.com:443").split(","))


async def pipe(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        while data := await reader.read(65536):
            writer.write(data)
            await writer.drain()
    except ConnectionError:
        pass
    finally:
        writer.close()


async def reply(writer: asyncio.StreamWriter, status: str) -> None:
    writer.write(f"HTTP/1.1 {status}\r\nContent-Length: 0\r\n\r\n".encode())
    await writer.drain()
    writer.close()


async def handle(client_r: asyncio.StreamReader, client_w: asyncio.StreamWriter) -> None:
    try:
        head = await client_r.readuntil(b"\r\n\r\n")
    except (asyncio.IncompleteReadError, asyncio.LimitOverrunError):
        client_w.close()
        return
    parts = head.split(b"\r\n", 1)[0].decode(errors="replace").split(" ")
    method, target = (parts + ["", ""])[:2]
    if method != "CONNECT" or target not in ALLOW:
        print(f"DENY  {method} {target}", flush=True)
        return await reply(client_w, "403 Forbidden")

    host, port = target.rsplit(":", 1)
    try:
        up_r, up_w = await asyncio.open_connection(host, int(port))
    except OSError as e:
        print(f"FAIL  {target}: {e}", flush=True)
        return await reply(client_w, "502 Bad Gateway")

    print(f"ALLOW {target}", flush=True)
    client_w.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
    await client_w.drain()
    await asyncio.gather(pipe(client_r, up_w), pipe(up_r, client_w))


async def main() -> None:
    server = await asyncio.start_server(handle, "0.0.0.0", 3128)
    print(f"llm-egress on :3128, allow={sorted(ALLOW)}", flush=True)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
