"""
UI server: serves the two-pane page and proxies the gateway's SSE stream
so the browser only needs to know about the UI's port (8080).
"""

import os

import httpx
from fastapi import FastAPI
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

GATEWAY_URL = os.getenv("GATEWAY_URL", "http://gateway:9000")

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def index():
    return FileResponse("static/index.html")


@app.get("/events")
async def events():
    client = httpx.AsyncClient(timeout=None)

    async def gen():
        try:
            async with client.stream("GET", f"{GATEWAY_URL}/events") as r:
                async for chunk in r.aiter_bytes():
                    yield chunk
        except httpx.HTTPError as e:
            # End the stream; the browser's EventSource reconnects on its own.
            yield f": gateway unavailable ({type(e).__name__})\n\n".encode()
        finally:
            await client.aclose()

    return StreamingResponse(gen(), media_type="text/event-stream")
