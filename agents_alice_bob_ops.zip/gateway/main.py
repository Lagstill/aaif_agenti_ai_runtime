"""
Gateway: the runtime layer that gives agents an actual self.

Every agent request passes L0 identity (bearer token) -> L1 capabilities (policy.yaml
regex) -> L2 risk (phi3:mini or a heuristic mock), then is forwarded to the tool.
Every decision is published as an event on /events. That stream IS the demo.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from collections import deque
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import httpx
import yaml
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from risk import make_scorer

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("gateway")

POLICY_FILE = os.getenv("POLICY_FILE", "/app/policy.yaml")

# --- policy ---------------------------------------------------------------

@dataclass
class Capability:
    tool: str
    method: str
    arg_patterns: dict[str, str] = field(default_factory=dict)

    def matches(self, tool: str, method: str, args: dict[str, Any]) -> tuple[bool, str]:
        if self.tool != tool or self.method != method:
            return False, "tool/method mismatch"
        for arg, pattern in self.arg_patterns.items():
            val = str(args.get(arg, ""))
            if not re.fullmatch(pattern, val):
                return False, f"arg '{arg}'={val!r} does not match {pattern!r}"
        return True, f"matched {tool}.{method} {self.arg_patterns}"


@dataclass
class Policy:
    caps: dict[str, list[Capability]]
    tool_urls: dict[str, str]
    identities: dict[str, str]  # token -> agent_name
    risk_may_block: set[str]    # "tool.method" where an L2 'deny' actually blocks

    @classmethod
    def load(cls, path: str) -> "Policy":
        with open(path) as f:
            raw = yaml.safe_load(f)
        caps = {
            agent: [Capability(e["tool"], e["method"], e.get("arg_patterns", {})) for e in entries]
            for agent, entries in (raw.get("capabilities") or {}).items()
        }
        # policy.yaml is written name -> token (readable); we look up token -> name.
        names_by_token = {token: name for name, token in (raw.get("identities") or {}).items()}
        if len(names_by_token) != len(raw.get("identities") or {}):
            raise ValueError("policy.yaml: every agent needs a unique token")
        return cls(caps=caps, tool_urls=raw.get("tool_urls", {}), identities=names_by_token,
                   risk_may_block=set(raw.get("risk_may_block") or []))

    def check(self, agent: str, tool: str, method: str, args: dict[str, Any]) -> tuple[bool, str]:
        last_reason = f"no capability for {agent} -> {tool}.{method}"
        for cap in self.caps.get(agent, []):
            ok, reason = cap.matches(tool, method, args)
            if ok:
                return True, reason
            if cap.tool == tool and cap.method == method:
                last_reason = reason  # right tool, wrong args: say which arg failed
        return False, last_reason


# --- event bus ------------------------------------------------------------

class EventBus:
    def __init__(self) -> None:
        self._subs: set[asyncio.Queue] = set()
        self._recent: deque[dict] = deque(maxlen=100)  # replayed to each new viewer

    async def publish(self, event: dict) -> None:
        event["ts"] = time.time()
        self._recent.append(event)
        for q in list(self._subs):
            q.put_nowait(event)

    @asynccontextmanager
    async def subscribe(self) -> AsyncIterator[asyncio.Queue]:
        q: asyncio.Queue = asyncio.Queue()
        for event in self._recent:
            q.put_nowait(event)
        self._subs.add(q)
        try:
            yield q
        finally:
            self._subs.discard(q)


bus = EventBus()

# --- app ------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.policy = Policy.load(POLICY_FILE)
    app.state.http = httpx.AsyncClient(timeout=30.0)
    app.state.risk = make_scorer(app.state.http)
    log.info("gateway ready, policy=%s, risk=%s", POLICY_FILE, type(app.state.risk).__name__)
    # Not awaited: a first-run model pull takes minutes; /health must answer now.
    warmup = asyncio.create_task(app.state.risk.warmup())
    yield
    warmup.cancel()
    await app.state.http.aclose()


app = FastAPI(lifespan=lifespan)


class ToolCall(BaseModel):
    tool: str
    method: str
    args: dict[str, Any] = {}


async def _check_identity(agent_name: str, request: Request) -> None:
    """L0. The URL claims 'I am agent_name'; the bearer token has to prove it."""
    policy: Policy = request.app.state.policy
    auth = request.headers.get("authorization", "")
    bearer = auth[len("bearer "):].strip() if auth.lower().startswith("bearer ") else None
    token_binds_to = policy.identities.get(bearer) if bearer else None

    allowed = token_binds_to == agent_name
    reason = ("ok" if allowed
              else "no bearer token" if not bearer
              else "token not recognized" if token_binds_to is None
              else f"token belongs to '{token_binds_to}', not '{agent_name}'")

    await bus.publish({
        "kind": "identity_check",
        "url_claims": agent_name, "token_binds_to": token_binds_to,
        "allowed": allowed, "reason": reason,
    })
    if not allowed:
        raise HTTPException(401, {"error": "identity_mismatch", "reason": reason})


@app.post("/agent/{agent_name}/tool")
async def call_tool(agent_name: str, call: ToolCall, request: Request):
    await _check_identity(agent_name, request)
    policy: Policy = request.app.state.policy
    http: httpx.AsyncClient = request.app.state.http

    # --- L1: hard capabilities ---
    cap_ok, cap_reason = policy.check(agent_name, call.tool, call.method, call.args)
    await bus.publish({
        "kind": "policy_decision",
        "agent": agent_name, "tool": call.tool, "method": call.method,
        "args": call.args, "allowed": cap_ok, "reason": cap_reason,
    })
    if not cap_ok:
        raise HTTPException(403, {"error": "capability_denied", "reason": cap_reason})

    # --- L2: fuzzy risk ---
    risk = await request.app.state.risk.score(agent_name, call.tool, call.method, call.args)
    if risk.choice == "deny" and f"{call.tool}.{call.method}" not in policy.risk_may_block:
        risk.choice = "warn"  # fuzzy layer has bounded authority: it can only flag this call
        risk.reason += f" (deny → warn: L2 may only block {sorted(policy.risk_may_block)})"
    await bus.publish({
        "kind": "risk_decision",
        "agent": agent_name, "tool": call.tool, "method": call.method,
        "choice": risk.choice, "confidence": risk.confidence,
        "reason": risk.reason, "source": risk.source,
    })
    if risk.choice == "deny":
        raise HTTPException(403, {"error": "risk_denied", "reason": risk.reason,
                                  "confidence": risk.confidence, "source": risk.source})

    # --- forward to the tool container ---
    url = policy.tool_urls.get(call.tool)
    if not url:
        raise HTTPException(500, {"error": "tool_not_configured", "tool": call.tool})

    started = time.monotonic()
    try:
        resp = await http.post(f"{url}/{call.method}", json=call.args)
        payload = resp.json()
    except (httpx.HTTPError, ValueError) as e:
        await bus.publish({
            "kind": "tool_error", "agent": agent_name,
            "tool": call.tool, "method": call.method, "error": f"{type(e).__name__}: {e}",
        })
        raise HTTPException(502, {"error": "tool_unreachable", "detail": str(e)})

    await bus.publish({
        "kind": "tool_result",
        "agent": agent_name, "tool": call.tool, "method": call.method,
        "status": resp.status_code, "duration_ms": int((time.monotonic() - started) * 1000),
        "result_preview": _preview(payload),
    })
    return payload


@app.post("/agent/{agent_name}/say")
async def agent_say(agent_name: str, request: Request):
    await _check_identity(agent_name, request)
    try:
        text = str((await request.json()).get("text", ""))
    except ValueError:
        raise HTTPException(400, {"error": "body must be JSON like {\"text\": \"...\"}"})
    await bus.publish({"kind": "agent_message", "agent": agent_name, "text": text})
    return {"ok": True}


@app.get("/events")
async def events():
    async def gen():
        async with bus.subscribe() as q:
            while True:
                try:
                    event = await asyncio.wait_for(q.get(), timeout=15.0)
                    yield f"data: {json.dumps(event)}\n\n"
                except asyncio.TimeoutError:
                    yield ": ping\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream")


@app.get("/health")
async def health():
    return {"ok": True}


def _preview(payload: Any, limit: int = 240) -> str:
    s = payload if isinstance(payload, str) else json.dumps(payload)
    return s if len(s) <= limit else s[:limit] + "…"
