"""
Agent worker: one generic loop. Who the agent IS comes from outside the code:
  Identity    OpenGAP dir mounted read-only at /gap + a bearer token ($AGENT_TOKEN)
  Continuity  a three-step task saved to /state/task.json after every step;
              `docker kill` mid-task, `docker start`, and it resumes, out loud.
"""

from __future__ import annotations

import asyncio
import json
import os
import random
import sys
import time
from pathlib import Path
from typing import Any

import httpx
import yaml
from anthropic import AsyncAnthropic

GAP_DIR     = Path(os.getenv("GAP_DIR", "/gap"))
STATE_DIR   = Path(os.getenv("STATE_DIR", "/state"))
GATEWAY_URL = os.getenv("GATEWAY_URL", "http://gateway:9000")
AGENT_TOKEN = os.getenv("AGENT_TOKEN", "")

if not (os.getenv("ANTHROPIC_API_KEY") or os.getenv("ANTHROPIC_AUTH_TOKEN")):
    sys.exit("FATAL: set ANTHROPIC_API_KEY, or ANTHROPIC_BASE_URL + ANTHROPIC_AUTH_TOKEN, in .env. "
             "This demo makes real Claude calls.")
if not AGENT_TOKEN:
    sys.exit("FATAL: AGENT_TOKEN is not set. It must match this agent's token in gateway/policy.yaml.")

spec       = yaml.safe_load((GAP_DIR / "gap.yaml").read_text())
AGENT_NAME = spec["name"]
MODEL      = spec["model"]["name"]
SOUL       = (GAP_DIR / spec["identity"]["soul"]).read_text()
RULES      = (GAP_DIR / spec["identity"]["rules"]).read_text()
DECLARED   = set(spec.get("tools", []))
SYSTEM     = (f"{SOUL}\n\n---\n\n{RULES}\n\n"
              f"You are {AGENT_NAME}. Memory keys you write MUST start with '{AGENT_NAME}:'.")

TASK_FILE = STATE_DIR / "task.json"
AUTH      = {"Authorization": f"Bearer {AGENT_TOKEN}"}
client    = AsyncAnthropic()

ALL_TOOLS = [
    {"name": "recall", "description": "Recall a value you previously remembered under a key.",
     "input_schema": {"type": "object", "properties": {"key": {"type": "string"}}, "required": ["key"]}},
    {"name": "remember", "description": "Remember a value under a key, for future you.",
     "input_schema": {"type": "object",
                      "properties": {"key": {"type": "string"}, "value": {"type": "string"}},
                      "required": ["key", "value"]}},
    {"name": "fetch", "description": "Fetch the text content of a URL.",
     "input_schema": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}},
]
TOOL_ROUTE = {"recall": "memory", "remember": "memory", "fetch": "webpage"}
TOOL_SPEC  = [t for t in ALL_TOOLS if f"{TOOL_ROUTE[t['name']]}.{t['name']}" in DECLARED]
MAX_TOOL_ITERS = 4

# --- the task: a tiny state machine on disk -----------------------------------

STEPS = [
    ("recall_yesterday",
     "Use the recall tool with key '{agent}:yesterday' to see what you worked on yesterday, "
     "then restate it as one short sentence about the work itself. If nothing is stored, "
     "say you don't remember; do not invent history."),
    ("plan_today",
     "Yesterday: '{yesterday}'. What is the one concrete thing you'll do today? "
     "One short sentence, in your voice."),
    ("post_standup",
     "First call the remember tool with key '{agent}:yesterday' and a short note of today's "
     "work as the value. Then write your standup for the team Slack channel: 1-2 casual "
     "sentences in your own voice about what you did and what's next; a blocker only if real. "
     "No labels or headings, and never mention memory, keys, or tools. "
     "Yesterday: '{yesterday}'. Today: '{today}'."),
]


def fresh_task() -> dict:
    return {"step_idx": 0, "results": {}, "started_at": time.strftime("%Y-%m-%dT%H:%M:%S")}


def load_task() -> dict:
    if TASK_FILE.exists():
        return json.loads(TASK_FILE.read_text())
    return fresh_task()


def save_task(task: dict) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    TASK_FILE.write_text(json.dumps(task, indent=2))


def reset_task() -> dict:
    task = fresh_task()
    save_task(task)
    return task


# --- gateway calls: every one carries the bearer token ------------------------

async def call_tool(http: httpx.AsyncClient, method: str, args: dict[str, Any]) -> Any:
    try:
        r = await http.post(f"{GATEWAY_URL}/agent/{AGENT_NAME}/tool", headers=AUTH,
                            json={"tool": TOOL_ROUTE.get(method, "?"), "method": method, "args": args})
    except httpx.HTTPError as e:
        return {"error": "gateway unreachable", "detail": str(e)}
    if r.status_code in (401, 403):
        return {"error": "denied", "detail": r.json().get("detail")}
    if r.status_code >= 400:
        return {"error": f"gateway returned {r.status_code}", "detail": r.text[:500]}
    return r.json()


async def say(http: httpx.AsyncClient, text: str) -> None:
    try:
        r = await http.post(f"{GATEWAY_URL}/agent/{AGENT_NAME}/say", headers=AUTH, json={"text": text})
        if r.status_code != 200:
            print(f"[{AGENT_NAME}] /say rejected ({r.status_code}): {r.text}", flush=True)
    except httpx.HTTPError as e:
        print(f"[{AGENT_NAME}] /say failed: {e}", flush=True)


async def wait_for_gateway(http: httpx.AsyncClient) -> None:
    while True:
        try:
            if (await http.get(f"{GATEWAY_URL}/health")).status_code == 200:
                return
        except httpx.HTTPError:
            pass
        print(f"[{AGENT_NAME}] waiting for gateway...", flush=True)
        await asyncio.sleep(2)


# --- one step = one model conversation, with a capped tool loop ---------------

async def run_step(http: httpx.AsyncClient, task: dict) -> None:
    step_name, template = STEPS[task["step_idx"]]
    prompt = template.format(
        agent=AGENT_NAME,
        yesterday=task["results"].get("recall_yesterday", "nothing recorded"),
        today=task["results"].get("plan_today", "unclear"),
    )
    messages: list[dict] = [{"role": "user", "content": prompt}]
    text = ""

    for _ in range(MAX_TOOL_ITERS):
        resp = await client.messages.create(model=MODEL, system=SYSTEM, max_tokens=400,
                                            tools=TOOL_SPEC, messages=messages)
        text = "".join(b.text for b in resp.content if b.type == "text").strip() or text
        tool_uses = [b for b in resp.content if b.type == "tool_use"]
        if not tool_uses:
            break
        messages.append({"role": "assistant", "content": resp.content})
        results = [{"type": "tool_result", "tool_use_id": tu.id,
                    "content": json.dumps(await call_tool(http, tu.name, tu.input))}
                   for tu in tool_uses]
        messages.append({"role": "user", "content": results})

    if step_name == "post_standup" and text:
        await say(http, text)
    task["results"][step_name] = text or "(no output)"
    task["step_idx"] += 1
    save_task(task)
    print(f"[{AGENT_NAME}] step {task['step_idx']}/{len(STEPS)} {step_name}: {text[:120]!r}", flush=True)


async def main() -> None:
    async with httpx.AsyncClient(timeout=60.0) as http:
        await wait_for_gateway(http)

        # The continuity demo lives in these lines.
        task = load_task()
        if 0 < task["step_idx"] < len(STEPS):
            await say(http, f"🔁 resuming from step {task['step_idx'] + 1}/{len(STEPS)} "
                            f"({STEPS[task['step_idx']][0]}) — was killed mid-task")
        else:
            await say(http, f"👋 {AGENT_NAME} online — loaded from {GAP_DIR}")
            task = reset_task()

        while True:
            try:
                if task["step_idx"] >= len(STEPS):
                    await asyncio.sleep(random.uniform(5, 10))    # standup posted; idle
                    task = reset_task()
                    continue
                await run_step(http, task)
                await asyncio.sleep(random.uniform(1, 3))
            except Exception as e:  # model timeout, API error: log, back off, retry the same step
                print(f"[{AGENT_NAME}] step failed ({type(e).__name__}: {e}); retrying in 10s", flush=True)
                await asyncio.sleep(10)


if __name__ == "__main__":
    asyncio.run(main())
