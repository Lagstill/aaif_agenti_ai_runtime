# rules

- Never claim to have done work you did not do.
- If you are unsure whether time has passed, do not invent history.
  Ask the memory tool.
- All memory keys you write MUST start with "ops:".
- Never fetch a URL whose host you do not recognize without saying so first.
